/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useRef, useEffect } from "react";
import { type UseChatReturn } from "@tanstack/ai-react";
import { type AnyClientTool, type MessagePart } from "@tanstack/ai-client";
import {
  Alert,
  Box,
  CircularProgress,
  Collapse,
  IconButton,
  InputAdornment,
  Paper,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import SmartToyIcon from "@mui/icons-material/SmartToy";
import PersonIcon from "@mui/icons-material/Person";
import BuildIcon from "@mui/icons-material/Build";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorIcon from "@mui/icons-material/Error";
import ReplayIcon from "@mui/icons-material/Replay";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import PsychologyIcon from "@mui/icons-material/Psychology";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

const JsonBlock = ({ label, data }: { label: string; data: unknown }) => {
  const [open, setOpen] = useState(false);
  return (
    <Box sx={{ mt: 0.5 }}>
      <Box
        onClick={() => setOpen((v) => !v)}
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 0.5,
        }}
      >
        {open ? (
          <ExpandLessIcon sx={{ fontSize: 13 }} />
        ) : (
          <ExpandMoreIcon sx={{ fontSize: 13 }} />
        )}
        <Typography
          variant="caption"
          sx={{ fontStyle: "italic", opacity: 0.85 }}
        >
          {label}
        </Typography>
      </Box>
      <Collapse in={open}>
        <Box
          component="pre"
          sx={{
            p: 1,
            mt: 0.5,
            m: 0,
            bgcolor: (theme) =>
              theme.palette.mode === "dark"
                ? "rgba(255,255,255,0.08)"
                : "rgba(0,0,0,0.08)",
            borderRadius: 1,
            fontSize: 11,
            overflowX: "auto",
            lineHeight: 1.5,
          }}
        >
          {typeof data === "object"
            ? JSON.stringify(data, null, 2)
            : String(data)}
        </Box>
      </Collapse>
    </Box>
  );
};

const ReasoningBlock = ({ content }: { content: string }) => {
  const [open, setOpen] = useState(false);
  return (
    <Box
      sx={{
        mb: 0.5,
        border: "1px dashed",
        borderColor: "divider",
        borderRadius: 1.5,
        p: 0.75,
        bgcolor: "action.hover",
        maxWidth: "90%",
      }}
    >
      <Box
        onClick={() => setOpen((v) => !v)}
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 0.5,
        }}
      >
        <PsychologyIcon sx={{ fontSize: 14, color: "text.secondary" }} />
        <Typography
          variant="caption"
          color="text.secondary"
          fontStyle="italic"
          sx={{ flexGrow: 1 }}
        >
          Reasoning
        </Typography>
        {open ? (
          <ExpandLessIcon sx={{ fontSize: 13, color: "text.secondary" }} />
        ) : (
          <ExpandMoreIcon sx={{ fontSize: 13, color: "text.secondary" }} />
        )}
      </Box>
      <Collapse in={open}>
        <Typography
          variant="caption"
          component="div"
          color="text.secondary"
          sx={{
            mt: 0.5,
            whiteSpace: "pre-wrap",
            fontStyle: "italic",
            maxHeight: 180,
            overflowY: "auto",
          }}
        >
          {content}
        </Typography>
      </Collapse>
    </Box>
  );
};

const ToolCallPart = <T extends AnyClientTool[]>({
  part,
}: {
  part: Extract<MessagePart<T>, { type: "tool-call" }>;
}) => {
  const isRunning = [
    "awaiting-input",
    "input-streaming",
    "input-complete",
  ].includes(part.state);
  const isError = (part.state as never) === "error";
  const isSuccess = ["output-complete", "output-streaming"].includes(
    part.state
  );

  let partInput: unknown = part.input ?? part.arguments;
  if (typeof partInput === "string") {
    try {
      partInput = JSON.parse(partInput);
    } catch {}
  }

  return (
    <Box
      sx={{
        mt: 0.75,
        p: 0.75,
        bgcolor: "action.hover",
        borderRadius: 1,
        border: "1px solid",
        borderColor: isError
          ? "error.light"
          : isSuccess
            ? "success.light"
            : "info.light",
      }}
    >
      <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
        <BuildIcon sx={{ fontSize: 13 }} />
        <Typography variant="caption" fontWeight={700}>
          {part.name}
        </Typography>
        <Box
          sx={{ ml: "auto", display: "flex", alignItems: "center", gap: 0.5 }}
        >
          {isRunning && (
            <>
              <CircularProgress size={10} />
              <Typography variant="caption" sx={{ opacity: 0.75 }}>
                calling…
              </Typography>
            </>
          )}
          {isSuccess && (
            <Tooltip title="Success">
              <CheckCircleIcon sx={{ fontSize: 13, color: "success.light" }} />
            </Tooltip>
          )}
          {isError && (
            <Tooltip title="Error">
              <ErrorIcon sx={{ fontSize: 13, color: "error.light" }} />
            </Tooltip>
          )}
        </Box>
      </Box>
      {partInput && <JsonBlock label="Input" data={partInput} />}
      {part.output !== undefined && (
        <JsonBlock label="Output" data={part.output} />
      )}
      {isError && (part as any).error && (
        <Typography
          variant="caption"
          color="error.light"
          sx={{ mt: 0.5, display: "block" }}
        >
          {String((part as any).error)}
        </Typography>
      )}
    </Box>
  );
};

export const ChatBot = <T extends AnyClientTool[]>({
  chat,
  exampleQuestions,
}: {
  chat: UseChatReturn<T>;
  exampleQuestions?: string[];
}) => {
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  const { messages, sendMessage, isLoading, error, reload } = chat;

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      sendMessage(input.trim());
      setInput("");
    }
  };

  return (
    <Box
      sx={{
        height: "100%",
        width: "100%",
        display: "flex",
        flexDirection: "column",
        p: 1.5,
        gap: 1,
        textAlign: "left",
      }}
    >
      {/* Messages */}
      <Paper
        variant="outlined"
        sx={{
          flex: 1,
          overflowY: "auto",
          p: 1.5,
          display: "flex",
          flexDirection: "column",
          gap: 1.5,
          bgcolor: "background.paper",
        }}
      >
        {messages.length === 0 && (
          <Typography
            variant="caption"
            color="text.secondary"
            textAlign="center"
            sx={{ mt: 3 }}
          >
            {exampleQuestions && exampleQuestions.length > 0
              ? `Try: "${exampleQuestions.join('" or "')}"`
              : 'Try: "What Exams do I have?"'}
          </Typography>
        )}

        {messages.map((message) => {
          const isAssistant = message.role === "assistant";
          const parts = message.parts ?? [];

          return (
            <Box
              key={message.id}
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: isAssistant ? "flex-start" : "flex-end",
              }}
            >
              {/* Role chip */}
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: 0.5,
                  mb: 0.25,
                }}
              >
                {isAssistant ? (
                  <SmartToyIcon sx={{ fontSize: 13 }} color="primary" />
                ) : (
                  <PersonIcon sx={{ fontSize: 13 }} color="action" />
                )}
                <Typography variant="caption" color="text.secondary">
                  {isAssistant ? "Assistant" : "You"}
                </Typography>
              </Box>

              {/* Reasoning (assistant only, outside bubble) */}
              {isAssistant &&
                parts
                  .filter(
                    (
                      p
                    ): p is Extract<
                      (typeof parts)[number],
                      { type: "thinking" }
                    > => p.type === "thinking"
                  )
                  .map((p, i) => (
                    <ReasoningBlock key={i} content={p.content} />
                  ))}

              {/* Bubble */}
              <Paper
                elevation={0}
                sx={{
                  px: 1.5,
                  py: 0.75,
                  maxWidth: "88%",
                  bgcolor: isAssistant
                    ? "primary.main"
                    : (theme) =>
                        theme.palette.mode === "dark"
                          ? theme.palette.grey[800]
                          : theme.palette.grey[100],
                  color: isAssistant ? "primary.contrastText" : "text.primary",
                  borderRadius: 2,
                }}
              >
                {parts.map((part, i) => {
                  if (part.type === "text") {
                    if (isAssistant) {
                      return (
                        <Box
                          key={i}
                          sx={{
                            "& p": { m: 0 },
                            "& p + p": { mt: 1 },
                            "& ul, & ol": { m: 0, pl: 2.5 },
                            "& code": {
                              bgcolor: "rgba(0,0,0,0.15)",
                              px: 0.5,
                              borderRadius: 0.5,
                              fontSize: "0.85em",
                            },
                            "& pre": {
                              bgcolor: "rgba(0,0,0,0.15)",
                              p: 1,
                              borderRadius: 1,
                              overflowX: "auto",
                              "& code": { bgcolor: "transparent", p: 0 },
                            },
                            "& table": {
                              width: "100%",
                              borderCollapse: "collapse",
                              my: 1,
                              fontSize: "0.85em",
                            },
                            "& th, & td": {
                              border: "1px solid rgba(255,255,255,0.3)",
                              px: 1,
                              py: 0.5,
                              textAlign: "left",
                            },
                            "& th": {
                              bgcolor: "rgba(0,0,0,0.15)",
                              fontWeight: 700,
                            },
                            "& tr:nth-of-type(even)": {
                              bgcolor: "rgba(0,0,0,0.07)",
                            },
                          }}
                        >
                          <Typography variant="body2" component="div">
                            <ReactMarkdown remarkPlugins={[remarkGfm]}>
                              {part.content}
                            </ReactMarkdown>
                          </Typography>
                        </Box>
                      );
                    }
                    return (
                      <Typography key={i} variant="body2" whiteSpace="pre-wrap">
                        {part.content}
                      </Typography>
                    );
                  }
                  if (part.type === "thinking") return null;
                  if (part.type === "tool-call")
                    return <ToolCallPart key={i} part={part} />;
                  return null;
                })}
              </Paper>
            </Box>
          );
        })}

        {isLoading && (
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.75 }}>
            <SmartToyIcon fontSize="small" color="primary" />
            <CircularProgress size={14} />
            <Typography variant="caption" color="text.secondary">
              Thinking…
            </Typography>
          </Box>
        )}

        {error && (
          <Alert
            severity="error"
            action={
              <IconButton
                size="small"
                color="inherit"
                onClick={() => reload()}
                aria-label="Retry"
              >
                <ReplayIcon fontSize="small" />
              </IconButton>
            }
            sx={{ mx: 0.5 }}
          >
            {error.message || "Something went wrong. Please try again."}
          </Alert>
        )}

        <div ref={bottomRef} />
      </Paper>

      {/* Input */}
      <Box
        component="form"
        onSubmit={handleSubmit}
        sx={{ bgcolor: "background.paper" }}
      >
        <TextField
          fullWidth
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Message…"
          disabled={isLoading}
          size="small"
          onSubmit={(e) => {
            handleSubmit(e);
          }}
          slotProps={{
            input: {
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    type="submit"
                    disabled={!input.trim() || isLoading}
                    size="small"
                    color="primary"
                  >
                    {isLoading ? (
                      <CircularProgress size={16} />
                    ) : (
                      <SendIcon fontSize="small" />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            },
          }}
        />
      </Box>
    </Box>
  );
};
