export { CourseDetailsModal } from "./CourseDetailsModal";
