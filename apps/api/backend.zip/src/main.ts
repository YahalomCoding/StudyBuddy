// Must be imported first to register OTel before any other modules
import "./instrumentation";
import { cleanupOpenApiDoc } from "nestjs-zod";
import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app/app.module";
import { DocumentBuilder, SwaggerModule } from "@nestjs/swagger";
import cookieParser from "cookie-parser";

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.use(cookieParser());

  app.enableCors({
    origin: true,
    credentials: true,
  });

  const config = new DocumentBuilder()
    .setTitle("StudyBuddy API")
    .setDescription("The StudyBuddy API description")
    .setVersion("1.0")
    .build();
  const documentFactory = () =>
    cleanupOpenApiDoc(SwaggerModule.createDocument(app, config));
  SwaggerModule.setup("api/docs", app, documentFactory);

  app.setGlobalPrefix("api");

  // eslint-disable-next-line turbo/no-undeclared-env-vars
  await app.listen(process.env.API_PORT ?? process.env.PORT ?? 3000);
}

// eslint-disable-next-line @typescript-eslint/no-floating-promises
bootstrap();
